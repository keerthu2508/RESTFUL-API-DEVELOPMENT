package com.example.icecreaminventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcecreaminventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(IcecreaminventoryApplication.class, args);
	}

}
