package com.example.icecreaminventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcecreaminventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
